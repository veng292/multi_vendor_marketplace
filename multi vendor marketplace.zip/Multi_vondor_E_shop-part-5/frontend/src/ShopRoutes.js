
import ShopHomePage from "../src/pages/Shop/ShopHomePage";

export { ShopHomePage };
